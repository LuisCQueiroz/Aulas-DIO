# O famoso “Hello, World”
print('Hello, World')
