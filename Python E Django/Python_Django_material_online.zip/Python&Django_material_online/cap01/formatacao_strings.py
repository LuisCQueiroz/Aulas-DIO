print('Hoje e dia %d' % 15)
print('12 em octal e %o' % 12)
print('255 em hexadecimal e %x' % 255)
print('pi com duas casas decimais e aproximadamente %.2f' % 3.1415926)
print('pi com tres casas decimais e aproximadamente %.3f' % 3.1415926)
nome = 'Francisco'
print('Meu nome e %s' % nome)
