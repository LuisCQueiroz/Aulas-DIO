cotacao_dolar_hoje = 3.766
valor_reais = 1000
valor_convertido = valor_reais / cotacao_dolar_hoje
print('\nR$ %.2f correspondem a US$ %.2f hoje' % (valor_reais, valor_convertido))

