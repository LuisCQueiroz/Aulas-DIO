cotacao_dolar_hoje = 3.766
valor_reais = 1000
valor_convertido = valor_reais / cotacao_dolar_hoje
print('\nR$', valor_reais, 'correspondem a US$', valor_convertido, 'hoje')
