altura = 1.5
largura = 5.0
comprimento = 6.0
area_base = largura ** comprimento  # * é o operador de multiplicação
volume = altura * area_base         # Volume em m3
print('O volume em m3 é ', volume)
