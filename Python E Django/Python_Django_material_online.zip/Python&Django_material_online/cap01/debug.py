#Python e Django: Desenvolvimento Web Moderno e ágil.
print('Usuário: Francisco Maciel')
print('Aniversário: 04 de outubro')
idade=42
serie='Game of Thrones'
livro='Odisseia'
print('Idade:', idade, ' anos')
print('Série favorita: ', serie)
print('Livro favorito: ', livros)
