import random
string = 'abacate laranja tomate'
print(random.choice(string))
lista = ['abacate','laranja','tomate']
print(random.choice(lista))
tupla = ('abacate','laranja','tomate')
print(random.choice(tupla))
