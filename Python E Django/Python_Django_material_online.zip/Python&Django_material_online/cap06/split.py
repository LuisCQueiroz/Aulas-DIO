# A linha seguinte poderia ter sido lida a partir de um arquivo:
linha = "7.0,3.2,4.7,1.4,versicolor"
dados = linha.split(',')
print("Linha original: ", linha)
print("Dados extraidos com split:", dados)
