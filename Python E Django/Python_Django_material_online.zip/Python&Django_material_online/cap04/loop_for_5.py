frase = "Conhecendo o Python"
for c in frase:
    print(c)
