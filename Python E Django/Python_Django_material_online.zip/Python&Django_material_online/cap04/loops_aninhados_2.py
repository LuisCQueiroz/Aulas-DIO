camisetas = ['azul','vermelha','amarela']
shorts = ['branco','preto']
x = 0
y = 0
for cor_camiseta in camisetas:
    for cor_short in shorts:
        print(f'Voce pode combinar uma camiseta {cor_camiseta} com um short {cor_short}')
