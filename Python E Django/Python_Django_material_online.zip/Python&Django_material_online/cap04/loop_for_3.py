print('Imprimindo os numeros de 0 a 9:')
for x in range(10):
    print(x, end=' ')
print('\nImprimindo os numeros de 1 a 10:')
for x in range(1,11):
    print(x, end=' ')
print('\nImprimindo os numeros IMPARES de 1 a 10:')
for x in range(1,11,2):
    print(x, end=' ')
print('\nImprimindo os numeros PARES de 0 a 10:')
for x in range(0,11,2):
    print(x, end=' ')
print('\nContagem regressiva de 10 a 0:')
for x in range(10,-1,-1):
    print(x, end=' ')
