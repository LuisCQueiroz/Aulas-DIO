alunos = ['Alice','Bob','Carl','Daniele']
for aluno_atual in alunos:
    print('O/A aluno(a) atualmente examinado(a) é %s' % aluno_atual)
