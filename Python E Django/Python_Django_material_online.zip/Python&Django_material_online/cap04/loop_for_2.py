for x in range(20):
    print('Aprendendo Python do jeito simples.')
