produtos = {}
produto1 = {
	'codigo': 1,
	'descricao': 'Mouse óptico sem fio',
	'preco': 50.0,
	'estoque': 130
}
produto2 = {
	'codigo': 2,
	'descricao': 'Teclado USB',
	'preco': 42.0,
	'estoque': 100
}
produto3 = {
	'codigo': 3,
	'descricao': 'Monitor colorido 20 pol.',
	'preco': 850.0,
	'estoque': 20
}
produto4 = {
	'codigo': 4,
	'descricao': 'Par de caixas de som',
	'preco': 90.0,
	'estoque': 17
}
produtos[1] = produto1
produtos[2] = produto2
produtos[3] = produto3
produtos[4] = produto4
