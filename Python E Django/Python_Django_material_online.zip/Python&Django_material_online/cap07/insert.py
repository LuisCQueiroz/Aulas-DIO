# Primeiro, crio uma lista com algumas marcas de veículos:
marcas_automoveis = ['Chevrolet','Fiat','Ford', 'Volkswagen']
print('Lista inicial de fabricantes: ', marcas_automoveis)
# Agora, adiciono mais duas, de forma a manter a ordem alfabética:
marcas_automoveis.insert(3, 'Hyundai')
print('A Hyundai abriu uma fábrica: ', marcas_automoveis)
marcas_automoveis.insert(4, 'Peugeot')
print('A Peugeot abriu uma fábrica: ', marcas_automoveis)
