lista_usuarios = []
lista_usuarios.append('francisco')
lista_usuarios.append('fulana')
lista_usuarios.append('cicrana')
lista_usuarios.append('beltrano')
print(lista_usuarios)
