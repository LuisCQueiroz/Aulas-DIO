# Primeiro, crio uma lista de alunos:
turma = ['Alice', 'Bob', 'Carl', 'Daniele', 'Eduard', 'Felicia']
print('Lista original: turma =', turma)
print('\"Fatiando\" os quatro primeiros de dois em dois: turma[0:4:2] = ', turma[0:4:2])
print('Ignorando os dois primeiros: turma[2:] = ', turma[2:])
print('Pegando até o quinto elemento: turma[:5] = ', turma[:5])
print('Retornando todo mundo de dois em dois a partir do início (índices pares): turma[::2] = ', turma[::2])
print('Retornando todo mundo de dois em dois a partir do segundo (índices ímpares): turma[1::2] = ', turma[1::2])
