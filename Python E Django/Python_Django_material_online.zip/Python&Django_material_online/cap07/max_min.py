lista_strings = ['AbC', 'dEf', '123', '456']
lista_ints = [5, 2, 3, 4, 1]
lista_floats = [6.2, 5.0, 7.1, 3.7, 20.5]
tupla_strings = ('casa', 'pato', 'abacaxi', 'ganso', 'caçador')
tupla_ints = (15, 12, 13, 14, 11)
tupla_floats = (62.2, 52.0, 72.1, 32.7, 202.5)
lista_diversos = ['AbC','123', 3, 4, 7.0, 3.5]
print(f'Na lista {lista_strings}, o maior valor é {max(lista_strings)} e o menor, {min(lista_strings)}')
print(f'Na lista {lista_ints}, o maior valor é {max(lista_ints)} e o menor, {min(lista_ints)}')
print(f'Na lista {lista_floats}, o maior valor é {max(lista_floats)} e o menor, {min(lista_floats)}')
print(f'Na tupla {tupla_strings}, o maior valor é {max(tupla_strings)} e o menor, {min(tupla_strings)}')
print(f'Na tupla {tupla_ints}, o maior valor é {max(tupla_ints)} e o menor, {min(tupla_ints)}')
print(f'Na tupla {tupla_floats}, o maior valor é {max(tupla_floats)} e o menor, {min(tupla_floats)}')
print(f'Na lista {lista_diversos}, o maior valor é {max(lista_diversos)} e o menor, {min(lista_diversos)}')
