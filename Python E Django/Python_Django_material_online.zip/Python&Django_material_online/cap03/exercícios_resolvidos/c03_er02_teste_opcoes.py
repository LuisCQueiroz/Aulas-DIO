opcao = input('Deseja realmente sair do sistema [S/N]?')
if(opcao=='S'):
    print('Você saiu do sistema.')
elif(opcao=='N'):
    print('Você continua no sistema.')
else:
    print('Opção inválida!')
