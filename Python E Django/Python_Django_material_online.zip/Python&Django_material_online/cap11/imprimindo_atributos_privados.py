print(f'código: {um_produto._Produto__codigo}')
print(f'descrição: {um_produto._Produto__descricao}')
print(f'preço: {um_produto._Produto__preco}')
print(f'quantidade em estoque: {um_produto._Produto__quantidade_estoque:.2f}')
