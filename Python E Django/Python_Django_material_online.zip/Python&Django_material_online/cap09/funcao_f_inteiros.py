""" Retorna o valor de f = (a + b) * x """

def f(a: int, b: int, x: int)->int:
    return (a + b) * x
