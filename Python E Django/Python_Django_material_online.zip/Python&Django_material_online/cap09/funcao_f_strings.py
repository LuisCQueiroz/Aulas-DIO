""" Retorna x vezes a concatenaçao de a com b """

def f(a: str, b: str, x: int)->int:
    return (a + b) * x
