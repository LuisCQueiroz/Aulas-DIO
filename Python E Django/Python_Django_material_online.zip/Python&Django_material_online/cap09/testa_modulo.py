import modulo_exemplo

print(f'A area de um circulo de raio 2.0 e {modulo_exemplo.area_circulo(2.0):.2f}')
print(f'A area de um triangulo de base 5.0 e altura 2.0 e {modulo_exemplo.area_triangulo(5.0, 2.0):.2f}')


