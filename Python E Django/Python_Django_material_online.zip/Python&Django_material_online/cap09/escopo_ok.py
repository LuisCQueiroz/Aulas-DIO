def func(a: int, b:int)->None:
    print(f'Foram recebidos os parâmetros a={a} e b={b}.')
    z = 5
    print(f'O valor de z é {z}')

func(1,2)
