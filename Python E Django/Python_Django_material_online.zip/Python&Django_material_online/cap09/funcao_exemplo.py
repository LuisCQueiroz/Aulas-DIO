""" Retorna o valor de f = (a + b) * x """

def f(a, b, x):
    return (a + b) * x
